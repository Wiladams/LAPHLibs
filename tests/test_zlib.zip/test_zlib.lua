package.path = package.path..";../?.lua";

local zlib = require("laphlibs.zlib")

